# Everything in One Update
Read how to download extension by clicking [here](https://github.com/3meraldK/earthmc-dynmap#2-ways-to-install-extension).

26.3 is a third major release of 2026, providing uncountably many tweaks, bugfixes and updates.

## Notable changes
- Downloading resources from the internet, such as alliance and API data is now handled by your browser entirely. This change eliminates the need of middle-man websites, much greater latencies, serviceability issues, and more to count
- The entire code base has been restructurised to multiple files and a compiler to merge them into a working extension. Redundant duplicate code has been obliterated
- You can now locate towns, nations and residents in all archive snapshots
- A layer of provincial borders, as well as country borders revised in more detailed manner. Reduced loading times of them
- A new option to toggle capital star icons
- A button to refresh site data, should be used to attempt to fix an issue or update something manually
- You can now zoom out by 2 levels, effectively allowing you to view the entire world at once
- In the archive mode, viewing snapshots other than from the world of Terra Nostra will overlay a satellite image of viewed world
- From now on, userscripts <u>SHOULD</u> automatically update

## Other changes
- Dark mode has been negligibly tweaked
- Custom chunk layer and player list have been deprecated
- Disabled archive mode for aurora.earthmc.net
- Fixed a bug occurring in the player list with scrolling
- Interface has been made less cluttered
- Fixed a town locator not working in archive mode

Click [here](https://github.com/3meraldK/earthmc-dynmap/compare/26.2...26.3) to see full list of changes since 26.2.